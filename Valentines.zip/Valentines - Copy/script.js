document.addEventListener("DOMContentLoaded", function () {
    const noButton = document.querySelector(".NO");
    const yesButton = document.querySelector(".YES");

    // Track how many times the "NO" button is clicked
    let noClicks = 0;

    noButton.addEventListener("click", function () {
        // Make the "YES" button bigger each time "NO" is clicked
        yesButton.style.fontSize = `${30 + noClicks * 5}px`;  // Increases font size gradually
        yesButton.style.padding = `${20 + noClicks * 5}px ${40 + noClicks * 5}px`; // Increases padding
        
        // Change the "NO" button text
        if (noClicks === 0) {
            noButton.textContent = "Are you sure?";
        } else if (noClicks === 1) {
            noButton.textContent = "Please...";
        } else if (noClicks === 2) {
            noButton.textContent = "You're making me sad.";
        } else if (noClicks === 3) {
            noButton.textContent = "I really want to be your valentine!";
        }
        
        noClicks++;
    });

    yesButton.addEventListener("click", function() {
        const questionText = document.querySelector(".question");
        questionText.innerText = 'YAY I KNEW YOU WOULD YIPPIE';
    
        // Change the image
        const mainImage = document.querySelector(".dogdance");
        mainImage.src = "Assets/pochacodancing.gif";  // Change to a different image of your choice
    
        // Hide the buttons
        const buttonContainer = document.querySelector(".button-container");
        buttonContainer.style.display = "none"; // Hides the buttons
    });
});

